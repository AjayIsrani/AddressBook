﻿using AddressBook_API.App_Code;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace AddressBook_API.Api
{   
    public class AddressBookController : ApiController
    {
        
        [HttpGet]
        public HttpResponseMessage GetCountryList(int UserID)
        {
            #region Get Country List
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_Country_SelectAllByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get Country List

        }

        [HttpGet]
        public HttpResponseMessage SelectCountryByPK(int ID)
        {
            #region Get State List By CountryID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_Country_SelectPK]";
                objCmd.Parameters.AddWithValue("@CountryID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get State List By CountryID
        }

        [HttpPost]
        public HttpResponseMessage Country_Insert([FromBody] FormDataCollection formbody, int UserID)
        {

            #region Declare Local Variables
            string ErrorMessage = "";
            SqlString CountryName = SqlString.Null;
            SqlString CountryCode = SqlString.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value

            if (formbody.GetValues("CountryName") == null)
                ErrorMessage += " - CountryName is Required Field <br />";
            else
                CountryName = formbody.Get("CountryName").ToString().Trim();

            if (formbody.GetValues("CountryCode") != null)
                CountryCode = formbody.Get("CountryCode").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Country_Insert]";
                objCmd.Parameters.AddWithValue("@CountryID", 4);
                objCmd.Parameters.AddWithValue("@CountryName", CountryName);
                objCmd.Parameters.AddWithValue("@CountryCode", CountryCode);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage Country_Update([FromBody] FormDataCollection formbody, int ID, int UserID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 CountryID = SqlInt32.Null;
            SqlString CountryName = SqlString.Null;
            SqlString CountryCode = SqlString.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("CountryID") == null)
            //    ErrorMessage += " - CountryID is Required Field <br />";
            //else
            //    CountryID = Convert.ToInt32(formbody.Get("CountryID").ToString().Trim());

            if (formbody.GetValues("CountryName") == null)
                ErrorMessage += " - CountryName is Required Field <br />";
            else
                CountryName = formbody.Get("CountryName").ToString().Trim();

            if (formbody.GetValues("CountryCode") != null)
                CountryCode = formbody.Get("CountryCode").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Country_Update]";
                objCmd.Parameters.AddWithValue("@CountryID", ID);
                objCmd.Parameters.AddWithValue("@CountryName", CountryName);
                objCmd.Parameters.AddWithValue("@CountryCode", CountryCode);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpDelete]
        public HttpResponseMessage Country_Delete(int ID)
        {
            #region Delete Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Country_Delete]";
                objCmd.Parameters.AddWithValue("@CountryID", ID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Deleted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Delete Data
        }

        [HttpGet]
        public HttpResponseMessage GetStateListByCountryID(int ID, int UserID)
        {
            #region Get State List By CountryID 
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_State_SelectDropDownListByCountryIDAndUserID]";
                objCmd.Parameters.AddWithValue("@CountryID", ID);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get State List By CountryID
        }

        [HttpGet]
        public HttpResponseMessage GetStateList(int UserID)
        {
            #region Get State List
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_State_SelectAllByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get State List

        }

        [HttpGet]
        public HttpResponseMessage SelectStateByPK(int ID)
        {
            #region Get State List By StateID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_State_SelectPK]";
                objCmd.Parameters.AddWithValue("@StateID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get State List By StateID
        }

        [HttpPost]
        public HttpResponseMessage State_Insert([FromBody] FormDataCollection formbody, int UserID)
        {

            #region Declare Local Variables
            string ErrorMessage = "";
            SqlString StateName = SqlString.Null;
            SqlInt32 CountryID = SqlInt32.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
           // SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value

            if (formbody.GetValues("StateName") == null)
                ErrorMessage += " - StateName is Required Field <br />";
            else
                StateName = formbody.Get("StateName").ToString().Trim();

            if (formbody.GetValues("CountryID") == null)
                ErrorMessage += " - CountryID is Required Field <br />";
            else
                CountryID = Convert.ToInt32(formbody.Get("CountryID").ToString().Trim());

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_State_Insert]";
                objCmd.Parameters.AddWithValue("@StateID", 4);
                objCmd.Parameters.AddWithValue("@CountryID", CountryID);
                objCmd.Parameters.AddWithValue("@StateName", StateName);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage State_Update([FromBody] FormDataCollection formbody, int ID, int UserID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 StateID = SqlInt32.Null;
            SqlString StateName = SqlString.Null;
            SqlInt32 CountryID = SqlInt32.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("StateID") == null)
            //    ErrorMessage += " - StateID is Required Field <br />";
            //else
            //    StateID = Convert.ToInt32(formbody.Get("StateID").ToString().Trim());

            if (formbody.GetValues("StateName") == null)
                ErrorMessage += " - StateName is Required Field <br />";
            else
                StateName = formbody.Get("StateName").ToString().Trim();

            if (formbody.GetValues("CountryID") == null)
                ErrorMessage += " - CountryID is Required Field <br />";
            else
                CountryID = Convert.ToInt32(formbody.Get("CountryID").ToString().Trim());

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_State_Update]";
                objCmd.Parameters.AddWithValue("@StateID", ID);
                objCmd.Parameters.AddWithValue("@CountryID", CountryID);
                objCmd.Parameters.AddWithValue("@StateName", StateName);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpDelete]
        public HttpResponseMessage State_Delete(int ID)
        {
            #region Delete Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_State_Delete]";
                objCmd.Parameters.AddWithValue("@StateID", ID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Deleted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Delete Data
        }

        [HttpGet]
        public HttpResponseMessage GetCityListByStateID(int ID, int UserID)
        {
            #region Get City List By StateID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_City_SelectDropDownListByStateIDUserID]";
                objCmd.Parameters.AddWithValue("@StateID", ID);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get City List By StateID
        }

        [HttpGet]
        public HttpResponseMessage GetCityList(int UserID)
        {
            #region Get City List
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_City_SelectAllByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get City List

        }

        [HttpGet]
        public HttpResponseMessage SelectCityByPK(int ID)
        {
            #region Get City List By CityID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_City_SelectPK]";
                objCmd.Parameters.AddWithValue("@CityID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get City List By CityID
        }

        [HttpPost]
        public HttpResponseMessage City_Insert([FromBody] FormDataCollection formbody, int UserID)
        {

            #region Declare Local Variables
            string ErrorMessage = "";
            SqlString CityName = SqlString.Null;
            SqlString Pincode = SqlString.Null;
            SqlString STDCode = SqlString.Null;
            SqlInt32 StateID = SqlInt32.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value

            if (formbody.GetValues("CityName") == null)
                ErrorMessage += " - CityName is Required Field <br />";
            else
                CityName = formbody.Get("CityName").ToString().Trim();

            if (formbody.GetValues("StateID") == null)
                ErrorMessage += " - StateID is Required Field <br />";
            else
                StateID = Convert.ToInt32(formbody.Get("StateID").ToString().Trim());

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("STDCode") == null)
                ErrorMessage += " - STDCode is Required Field <br />";
            else
                STDCode = formbody.Get("STDCode").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
           // UserID = 1;

            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_City_Insert]";
                objCmd.Parameters.AddWithValue("@CityID", 4);
                objCmd.Parameters.AddWithValue("@CityName", CityName);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@STDCode", STDCode);
                objCmd.Parameters.AddWithValue("@StateID", StateID);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage City_Update([FromBody] FormDataCollection formbody, int ID, int UserID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 CityID = SqlInt32.Null;
            SqlString CityName = SqlString.Null;
            SqlString Pincode = SqlString.Null;
            SqlString STDCode = SqlString.Null;
            SqlInt32 StateID = SqlInt32.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("CityID") == null)
            //    ErrorMessage += " - CityID is Required Field <br />";
            //else
            //    CityID = Convert.ToInt32(formbody.Get("CityID").ToString().Trim());

            if (formbody.GetValues("CityName") == null)
                ErrorMessage += " - CityName is Required Field <br />";
            else
                CityName = formbody.Get("CityName").ToString().Trim();

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("STDCode") == null)
                ErrorMessage += " - STDCode is Required Field <br />";
            else
                STDCode = formbody.Get("STDCode").ToString().Trim();

            if (formbody.GetValues("StateID") == null)
                ErrorMessage += " - StateID is Required Field <br />";
            else
                StateID = Convert.ToInt32(formbody.Get("StateID").ToString().Trim());

           

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_City_Update]";
                objCmd.Parameters.AddWithValue("@CityID", ID);
                objCmd.Parameters.AddWithValue("@CityName", CityName);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@STDCode", STDCode);
                objCmd.Parameters.AddWithValue("@StateID", StateID);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpDelete]
        public HttpResponseMessage City_Delete(int ID)
        {
            #region Delete Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_City_Delete]";
                objCmd.Parameters.AddWithValue("@CityID", ID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Deleted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Delete Data
        }

        [HttpGet]
        public HttpResponseMessage GetContactCategoryList(int UserID)
        {
            #region Get ContactCategory List
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_ContactCategory_SelectAllByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get ContactCategory List

        }

        [HttpGet]
        public HttpResponseMessage SelectContactCategoryByPK(int ID)
        {
            #region Get State List By ContactCategoryID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_ContactCategory_SelectPK]";
                objCmd.Parameters.AddWithValue("@ContactCategoryID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get State List By ContactCategoryID
        }

        [HttpPost]
        public HttpResponseMessage ContactCategory_Insert([FromBody] FormDataCollection formbody, int UserID)
        {

            #region Declare Local Variables
            string ErrorMessage = "";
            SqlString ContactCategoryName = SqlString.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value

            if (formbody.GetValues("ContactCategoryName") == null)
                ErrorMessage += " - ContactCategoryName is Required Field <br />";
            else
                ContactCategoryName = formbody.Get("ContactCategoryName").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_ContactCategory_Insert]";
                objCmd.Parameters.AddWithValue("@ContactCategoryID", 4);
                objCmd.Parameters.AddWithValue("@ContactCategoryName", ContactCategoryName);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage ContactCategory_Update([FromBody] FormDataCollection formbody, int ID, int UserID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 ContactCategoryID = SqlInt32.Null;
            SqlString ContactCategoryName = SqlString.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            //SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("ContactCategoryID") == null)
            //    ErrorMessage += " - ContactCategoryID is Required Field <br />";
            //else
            //    ContactCategoryID = Convert.ToInt32(formbody.Get("ContactCategoryID").ToString().Trim());

            if (formbody.GetValues("ContactCategoryName") == null)
                ErrorMessage += " - ContactCategoryName is Required Field <br />";
            else
                ContactCategoryName = formbody.Get("ContactCategoryName").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
            //UserID = 1;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_ContactCategory_Update]";
                objCmd.Parameters.AddWithValue("@ContactCategoryID", ID);
                objCmd.Parameters.AddWithValue("@ContactCategoryName", ContactCategoryName);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpDelete]
        public HttpResponseMessage ContactCategory_Delete(int ID)
        {
            #region Delete Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_ContactCategory_Delete]";
                objCmd.Parameters.AddWithValue("@ContactCategoryID", ID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Deleted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Delete Data
        }

        [HttpGet]
        public HttpResponseMessage GetContactList(int UserID)
        {
            #region Get Contact List
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_Contact_SelectAllByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get Contact List

        }

        [HttpGet]
        public HttpResponseMessage SelectContactByPK(int ID)
        {
            #region Get Contact List By ContactID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_Contact_SelectPK]";
                objCmd.Parameters.AddWithValue("@ContactID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get Contact List By ContactID
        }

        [HttpPost]
        public HttpResponseMessage Contact_Insert([FromBody] FormDataCollection formbody, int UserID)
        {

            #region Declare Local Variables
            string ErrorMessage = "";
            SqlInt32 ContactCategoryID	= SqlInt32.Null;
            SqlString ContactName		= SqlString.Null;
            SqlString Address           = SqlString.Null;
            SqlString  Pincode			= SqlString.Null;
            SqlInt32  CityID			= SqlInt32.Null;	
            SqlInt32  StateID			= SqlInt32.Null;
            SqlInt32  CountryID			= SqlInt32.Null;
            SqlString  EmailAddress		= SqlString.Null;
            SqlString MobileNo			= SqlString.Null;
            SqlString FaceBookID		= SqlString.Null;
            SqlString LinkedinID        = SqlString.Null;
            SqlDateTime Created         = SqlDateTime.Null;
            SqlDateTime Modified        = SqlDateTime.Null;
            //SqlInt32 UserID             = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            if (formbody.GetValues("ContactCategoryID") == null)
                ErrorMessage += " - ContactCategoryID is Required Field <br />";
            else
                ContactCategoryID = Convert.ToInt32(formbody.Get("ContactCategoryID").ToString().Trim());

            if (formbody.GetValues("ContactName") == null)
                ErrorMessage += " - ContactName is Required Field <br />";
            else
                ContactName = formbody.Get("ContactName").ToString().Trim();

            if (formbody.GetValues("Address") == null)
                ErrorMessage += " - Address is Required Field <br />";
            else
                Address = formbody.Get("Address").ToString().Trim();

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("CityID") == null)
                ErrorMessage += " - CityID is Required Field <br />";
            else
                CityID = Convert.ToInt32(formbody.Get("CityID").ToString().Trim());

            if (formbody.GetValues("StateID") == null)
                ErrorMessage += " - StateID is Required Field <br />";
            else
                StateID = Convert.ToInt32(formbody.Get("StateID").ToString().Trim());

            if (formbody.GetValues("CountryID") == null)
                ErrorMessage += " - CountryID is Required Field <br />";
            else
                CountryID = Convert.ToInt32(formbody.Get("CountryID").ToString().Trim());

            if (formbody.GetValues("EmailAddress") == null)
                ErrorMessage += " - EmailAddress is Required Field <br />";
            else
                EmailAddress = formbody.Get("EmailAddress").ToString().Trim();

            if (formbody.GetValues("MobileNo") == null)
                ErrorMessage += " - MobileNo is Required Field <br />";
            else
                MobileNo = formbody.Get("MobileNo").ToString().Trim();

            if (formbody.GetValues("FaceBookID") == null)
                ErrorMessage += " - FaceBookID is Required Field <br />";
            else
                FaceBookID = formbody.Get("FaceBookID").ToString().Trim();

            if (formbody.GetValues("LinkedinID") == null)
                ErrorMessage += " - LinkedinID is Required Field <br />";
            else
                LinkedinID = formbody.Get("LinkedinID").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
           // UserID = 1;

            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Contact_Insert]";
                objCmd.Parameters.AddWithValue("@ContactID", 4);
                objCmd.Parameters.AddWithValue("@ContactCategoryID", ContactCategoryID);
                objCmd.Parameters.AddWithValue("@ContactName", ContactName);
                objCmd.Parameters.AddWithValue("@Address", Address);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@CityID", CityID);
                objCmd.Parameters.AddWithValue("@StateID", StateID);
                objCmd.Parameters.AddWithValue("@CountryID", CountryID);
                objCmd.Parameters.AddWithValue("@EmailAddress", EmailAddress);
                objCmd.Parameters.AddWithValue("@MobileNo", MobileNo);
                objCmd.Parameters.AddWithValue("@FaceBookID", FaceBookID);
                objCmd.Parameters.AddWithValue("@LinkedinID", LinkedinID);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage Contact_Update([FromBody] FormDataCollection formbody, int ID, int UserID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 ContactID = SqlInt32.Null;
            SqlInt32 ContactCategoryID = SqlInt32.Null;
            SqlString ContactName = SqlString.Null;
            SqlString Address = SqlString.Null;
            SqlString Pincode = SqlString.Null;
            SqlInt32 CityID = SqlInt32.Null;
            SqlInt32 StateID = SqlInt32.Null;
            SqlInt32 CountryID = SqlInt32.Null;
            SqlString EmailAddress = SqlString.Null;
            SqlString MobileNo = SqlString.Null;
            SqlString FaceBookID = SqlString.Null;
            SqlString LinkedinID = SqlString.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
           // SqlInt32 UserID = SqlInt32.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("ContactID") == null)
            //    ErrorMessage += " - ContactID is Required Field <br />";
            //else
            //    ContactID = Convert.ToInt32(formbody.Get("ContactID").ToString().Trim());

            if (formbody.GetValues("ContactCategoryID") == null)
                ErrorMessage += " - ContactCategoryID is Required Field <br />";
            else
                ContactCategoryID = Convert.ToInt32(formbody.Get("ContactCategoryID").ToString().Trim());

            if (formbody.GetValues("ContactName") == null)
                ErrorMessage += " - ContactName is Required Field <br />";
            else
                ContactName = formbody.Get("ContactName").ToString().Trim();

            if (formbody.GetValues("Address") == null)
                ErrorMessage += " - Address is Required Field <br />";
            else
                Address = formbody.Get("Address").ToString().Trim();

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("CityID") == null)
                ErrorMessage += " - CityID is Required Field <br />";
            else
                CityID = Convert.ToInt32(formbody.Get("CityID").ToString().Trim());

            if (formbody.GetValues("StateID") == null)
                ErrorMessage += " - StateID is Required Field <br />";
            else
                StateID = Convert.ToInt32(formbody.Get("StateID").ToString().Trim());

            if (formbody.GetValues("CountryID") == null)
                ErrorMessage += " - CountryID is Required Field <br />";
            else
                CountryID = Convert.ToInt32(formbody.Get("CountryID").ToString().Trim());

            if (formbody.GetValues("EmailAddress") == null)
                ErrorMessage += " - EmailAddress is Required Field <br />";
            else
                EmailAddress = formbody.Get("EmailAddress").ToString().Trim();

            if (formbody.GetValues("MobileNo") == null)
                ErrorMessage += " - MobileNo is Required Field <br />";
            else
                MobileNo = formbody.Get("MobileNo").ToString().Trim();

            if (formbody.GetValues("FaceBookID") == null)
                ErrorMessage += " - FaceBookID is Required Field <br />";
            else
                FaceBookID = formbody.Get("FaceBookID").ToString().Trim();

            if (formbody.GetValues("LinkedinID") == null)
                ErrorMessage += " - LinkedinID is Required Field <br />";
            else
                LinkedinID = formbody.Get("LinkedinID").ToString().Trim();

            Created = DateTime.Now;
            Modified = DateTime.Now;
           // UserID = 1;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Contact_Update]";
                objCmd.Parameters.AddWithValue("@ContactID", ID);
                objCmd.Parameters.AddWithValue("@ContactCategoryID", ContactCategoryID);
                objCmd.Parameters.AddWithValue("@ContactName", ContactName);
                objCmd.Parameters.AddWithValue("@Address", Address);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@CityID", CityID);
                objCmd.Parameters.AddWithValue("@StateID", StateID);
                objCmd.Parameters.AddWithValue("@CountryID", CountryID);
                objCmd.Parameters.AddWithValue("@EmailAddress", EmailAddress);
                objCmd.Parameters.AddWithValue("@MobileNo", MobileNo);
                objCmd.Parameters.AddWithValue("@FaceBookID", FaceBookID);
                objCmd.Parameters.AddWithValue("@LinkedinID", LinkedinID);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.Parameters.AddWithValue("@UserID", UserID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpDelete]
        public HttpResponseMessage Contact_Delete(int ID)
        {
            #region Delete Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_Contact_Delete]";
                objCmd.Parameters.AddWithValue("@ContactID", ID);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Deleted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Delete Data
        }

        [HttpGet]
        public HttpResponseMessage CheckByUserName(String UserName)
        {
            #region Get User By UserName
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_MasterUser_CheckByUserName]";
                objCmd.Parameters.AddWithValue("@UserName", UserName);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                EntityWrapper ent = new EntityWrapper();
                if (dt != null && dt.Rows.Count > 0)
                {
                    ent.IsResult = 1;
                    ent.Message = "User Name " + UserName + " Is Already Exsist";
                    ent.ResultList = dt;
                    return Request.CreateResponse(HttpStatusCode.OK, ent);
                }
                else
                {
                    ent.IsResult = 0;
                    ent.Message = "Valid Username";
                    return Request.CreateResponse(HttpStatusCode.OK, ent);
                }
                //return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion  Get User By UserName
        }

        [HttpGet]
        public HttpResponseMessage SelectByUserNameAndPassword(String UserName, String Password)
        {
            #region Get User By UserNameAndPassword
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_MasterUser_SelectByUserNameAndPassword]";
                objCmd.Parameters.AddWithValue("@UserName", UserName);
                objCmd.Parameters.AddWithValue("@Password", Password);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                EntityWrapper ent = new EntityWrapper();
                if (dt != null && dt.Rows.Count > 0)
                {
                    ent.IsResult = 1;
                    ent.Message = "Data Found";
                    ent.ResultList = dt;
                    return Request.CreateResponse(HttpStatusCode.OK, ent);
                }
                else
                {
                    ent.IsResult = 0;
                    ent.Message = "Invalid Username or Password";
                    return Request.CreateResponse(HttpStatusCode.OK, ent);
                }
                //return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion  Get User By UserNameAndPassword
        }


        [HttpGet]
        public HttpResponseMessage SelectUserByPK(int ID)
        {
            #region Get User List By UserID
            try
            {
                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = @"[dbo].[PR_MasterUser_SelectPK]";
                objCmd.Parameters.AddWithValue("@UserID", ID);
                SqlDataReader objSDR = objCmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(objSDR);
                objConn.Close();
                return GetResponseResult(dt);
            }
            catch (Exception ex)
            {
                return
                    GetResponseError(ex);
            }
            #endregion Get User List By UserID
        }

        [HttpPost]
        public HttpResponseMessage User_Insert([FromBody] FormDataCollection formbody)
        {
            
            #region Declare Local Variables
            string ErrorMessage = "";
            SqlString UserName = SqlString.Null;
            SqlString Password = SqlString.Null;
            SqlString FullName = SqlString.Null;
            SqlString Address = SqlString.Null;
            SqlString Pincode = SqlString.Null;
            SqlString EmailID = SqlString.Null;
            SqlString MobileNo = SqlString.Null;
            SqlString FaceBookID = SqlString.Null;
            SqlString LinkedinID = SqlString.Null;
            SqlDateTime Birthdate = SqlDateTime.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            if (formbody.GetValues("UserName") == null)
                ErrorMessage += " - UserName is Required Field <br />";
            else
                UserName = formbody.Get("UserName").ToString().Trim();

            if (formbody.GetValues("Password") == null)
                ErrorMessage += " - Password is Required Field <br />";
            else
                Password = formbody.Get("Password").ToString().Trim();

            if (formbody.GetValues("FullName") == null)
                ErrorMessage += " - FullName is Required Field <br />";
            else
                FullName = formbody.Get("FullName").ToString().Trim();

            if (formbody.GetValues("Address") == null)
                ErrorMessage += " - Address is Required Field <br />";
            else
                Address = formbody.Get("Address").ToString().Trim();

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("EmailID") == null)
                ErrorMessage += " - EmailID is Required Field <br />";
            else
                EmailID = formbody.Get("EmailID").ToString().Trim();

            if (formbody.GetValues("MobileNo") == null)
                ErrorMessage += " - MobileNo is Required Field <br />";
            else
                MobileNo = formbody.Get("MobileNo").ToString().Trim();

            if (formbody.GetValues("FaceBookID") == null)
                ErrorMessage += " - FaceBookID is Required Field <br />";
            else
                FaceBookID = formbody.Get("FaceBookID").ToString().Trim();

            if (formbody.GetValues("LinkedinID") == null)
                ErrorMessage += " - LinkedinID is Required Field <br />";
            else
                LinkedinID = formbody.Get("LinkedinID").ToString().Trim();

            if (formbody.GetValues("Birthdate") == null)
                ErrorMessage += " - Birthdate is Required Field <br />";
            else
                Birthdate = Convert.ToDateTime(formbody.Get("Birthdate").ToString().Trim());

            Created = DateTime.Now;
            Modified = DateTime.Now;


            #endregion Read Form Value

            #region Insert Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_MasterUser_Insert]";
                objCmd.Parameters.AddWithValue("@UserID", 4);
                objCmd.Parameters.AddWithValue("@UserName", UserName);
                objCmd.Parameters.AddWithValue("@Password", Password);
                objCmd.Parameters.AddWithValue("@FullName", FullName);
                objCmd.Parameters.AddWithValue("@Address", Address);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@EmailID", EmailID);
                objCmd.Parameters.AddWithValue("@MobileNo", MobileNo);
                objCmd.Parameters.AddWithValue("@FaceBookID", FaceBookID);
                objCmd.Parameters.AddWithValue("@LinkedinID", LinkedinID);
                objCmd.Parameters.AddWithValue("@Birthdate", Birthdate);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Inserted Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Insert Data
        }

        [HttpPut]
        public HttpResponseMessage User_Update([FromBody] FormDataCollection formbody, int ID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 UserID = SqlInt32.Null;
            SqlString UserName = SqlString.Null;
            //SqlString Password = SqlString.Null;
            SqlString FullName = SqlString.Null;
            SqlString Address = SqlString.Null;
            SqlString Pincode = SqlString.Null;
            SqlString EmailID = SqlString.Null;
            SqlString MobileNo = SqlString.Null;
            SqlString FaceBookID = SqlString.Null;
            SqlString LinkedinID = SqlString.Null;
            SqlDateTime Birthdate = SqlDateTime.Null;
            SqlDateTime Created = SqlDateTime.Null;
            SqlDateTime Modified = SqlDateTime.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("UserID") == null)
            //    ErrorMessage += " - UserID is Required Field <br />";
            //else
            //    UserID = Convert.ToInt32(formbody.Get("UserID").ToString().Trim());

            if (formbody.GetValues("UserName") == null)
                ErrorMessage += " - UserName is Required Field <br />";
            else
                UserName = formbody.Get("UserName").ToString().Trim();

            //if (formbody.GetValues("Password") == null)
            //    ErrorMessage += " - Password is Required Field <br />";
            //else
            //    Password = formbody.Get("Password").ToString().Trim();

            if (formbody.GetValues("FullName") == null)
                ErrorMessage += " - FullName is Required Field <br />";
            else
                FullName = formbody.Get("FullName").ToString().Trim();

            if (formbody.GetValues("Address") == null)
                ErrorMessage += " - Address is Required Field <br />";
            else
                Address = formbody.Get("Address").ToString().Trim();

            if (formbody.GetValues("Pincode") == null)
                ErrorMessage += " - Pincode is Required Field <br />";
            else
                Pincode = formbody.Get("Pincode").ToString().Trim();

            if (formbody.GetValues("EmailID") == null)
                ErrorMessage += " - EmailID is Required Field <br />";
            else
                EmailID = formbody.Get("EmailID").ToString().Trim();

            if (formbody.GetValues("MobileNo") == null)
                ErrorMessage += " - MobileNo is Required Field <br />";
            else
                MobileNo = formbody.Get("MobileNo").ToString().Trim();

            if (formbody.GetValues("FaceBookID") == null)
                ErrorMessage += " - FaceBookID is Required Field <br />";
            else
                FaceBookID = formbody.Get("FaceBookID").ToString().Trim();

            if (formbody.GetValues("LinkedinID") == null)
                ErrorMessage += " - LinkedinID is Required Field <br />";
            else
                LinkedinID = formbody.Get("LinkedinID").ToString().Trim();

            if (formbody.GetValues("Birthdate") == null)
                ErrorMessage += " - Birthdate is Required Field <br />";
            else
                Birthdate = Convert.ToDateTime(formbody.Get("Birthdate").ToString().Trim());

            Created = DateTime.Now;
            Modified = DateTime.Now;

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_MasterUser_Update]";
                objCmd.Parameters.AddWithValue("@UserID", ID);
                objCmd.Parameters.AddWithValue("@UserName", UserName);
                //objCmd.Parameters.AddWithValue("@Password", Password);
                objCmd.Parameters.AddWithValue("@FullName", FullName);
                objCmd.Parameters.AddWithValue("@Address", Address);
                objCmd.Parameters.AddWithValue("@Pincode", Pincode);
                objCmd.Parameters.AddWithValue("@EmailID", EmailID);
                objCmd.Parameters.AddWithValue("@MobileNo", MobileNo);
                objCmd.Parameters.AddWithValue("@FaceBookID", FaceBookID);
                objCmd.Parameters.AddWithValue("@LinkedinID", LinkedinID);
                objCmd.Parameters.AddWithValue("@Birthdate", Birthdate);
                objCmd.Parameters.AddWithValue("@Created", Created);
                objCmd.Parameters.AddWithValue("@Modified", Modified);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        [HttpPut]
        public HttpResponseMessage User_UpdatePassword([FromBody] FormDataCollection formbody,int ID)
        {
            #region Declare Local Variables
            string ErrorMessage = "";
            //SqlInt32 UserID = SqlInt32.Null;
            SqlString Password = SqlString.Null;
            #endregion Declare Local Variables

            #region Read Form Value
            //if (formbody.GetValues("UserID") == null)
            //    ErrorMessage += " - UserID is Required Field <br />";
            //else
            //    UserID = Convert.ToInt32(formbody.Get("UserID").ToString().Trim());

            if (formbody.GetValues("Password") == null)
                ErrorMessage += " - Password is Required Field <br />";
            else
                Password = formbody.Get("Password").ToString().Trim();

            #endregion Read Form Value

            #region Update Data

            try
            {

                SqlConnection objConn = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBook_3TireConnectionString"].ToString().Trim());
                objConn.Open();
                SqlCommand objCmd = objConn.CreateCommand();
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.CommandText = "[dbo].[PR_MasterUser_UpdatePasswordByUserID]";
                objCmd.Parameters.AddWithValue("@UserID", ID);
                objCmd.Parameters.AddWithValue("@Password", Password);
                objCmd.ExecuteNonQuery();
                objConn.Close();

                EntityWrapper ent = new EntityWrapper();
                ent.IsResult = 1;
                ent.Message = "Record Updated Successfully";

                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            catch (Exception ex)
            {
                return GetResponseError(ex);
            }
            #endregion Update Data
        }

        public HttpResponseMessage GetResponseResult(DataTable dt)
        {
            EntityWrapper ent = new EntityWrapper();
            if (dt != null && dt.Rows.Count > 0)
            {
                ent.IsResult = 1;
                ent.Message = "Data Found";
                ent.ResultList = dt;
                //JsonConvert.SerializeObject(dt)
                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
            else
            {
                ent.IsResult = 0;
                ent.Message = "No Data Found";
                return Request.CreateResponse(HttpStatusCode.OK, ent);
            }
        }
        public HttpResponseMessage GetResponseError(Exception ex)
        {
            EntityWrapper ent = new EntityWrapper();
            ent.IsResult = 0;
            ent.Message = ex.Message.ToString();
            return Request.CreateResponse(HttpStatusCode.OK, ent);
        }
    }
}