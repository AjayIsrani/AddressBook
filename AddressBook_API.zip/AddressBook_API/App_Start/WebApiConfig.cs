﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Net.Http;

namespace AddressBook_API.App_Start
{
    public class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(name: "Api_AddressBook_CheckByUserName",
            routeTemplate: "Api/AB/{controller}/{UserID}/CheckByUserName/{UserName}",
            defaults: new { });

            config.Routes.MapHttpRoute(name: "Api_AddressBook_SelectByUserNameAndPassword",
              routeTemplate: "Api/AB/{controller}/SelectByUserNameAndPassword/{UserName}/{Password}",
              defaults: new { });

            config.Routes.MapHttpRoute(
               name: "Api_AddressBook_Country_Insert",
               routeTemplate: "Api/AB/{controller}/{UserID}/{action}",
               defaults: new { }
               );

            config.Routes.MapHttpRoute(
              name: "Api_AddressBook_Country_Update",
              routeTemplate: "Api/AB/{controller}/{UserID}/{action}/{ID}",
              defaults: new { }
              );

            config.Routes.MapHttpRoute(
              name: "Api_AddressBook_Country_Delete",
              routeTemplate: "Api/AB/{controller}/{UserID}/{action}/{ID}",
              defaults: new { }
              );

            config.Routes.MapHttpRoute(
              name: "Api_AddressBook_SelectCountryByPK",
              routeTemplate: "Api/AB/{controller}/{UserID}/{action}/{ID}",
              defaults: new { }
              );

            config.Routes.MapHttpRoute(name: "Api_AddressBook_GetStateListByCountryID",
               routeTemplate: "Api/AB/{controller}/{UserID}/{action}/{ID}",
               defaults: new { });

            config.Routes.MapHttpRoute(name: "Api_AddressBook_GetCountryList",
                routeTemplate: "Api/AB/{controller}/{UserID}/{action}/Countries",
                defaults: new { });

           

           
        }
    }
}